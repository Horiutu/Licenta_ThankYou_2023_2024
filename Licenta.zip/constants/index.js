export const categories = [
  {
    id: 1,
    name: "Pizza",
  },
  {
    id: 2,
    name: "Burger",
  },
  {
    id: 3,
    name: "Italian",
  },
  {
    id: 4,
    name: "Chinese",
  },
  {
    id: 5,
    name: "Noodles",
  },
  {
    id: 6,
    name: "Sweets",
  },
  {
    id: 7,
    name: "American",
  },
  {
    id: 8,
    name: "Romanian",
  },
  {
    id: 9,
    name: "Drinks",
  },
];

export const featured = {
  id: 1,
  title: "Popular",
  description: "Most recently appreciated",
  restaurants: [
    {
      id: 1,
      name: "Papa Johns",
      image: require("../assets/images/pizza.png"),
      description: "Hot and spicy pizzas",
      lng: -85.5324269,
      lat: 38.2145602,
      address: "434 second street",
      stars: 4.4,
      reviews: "4.4k",
      category: "Italian",
      dishes: [
        {
          id: 1,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
        {
          id: 2,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
        {
          id: 3,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
      ],
    },
    {
      id: 2,
      name: "Horia Cuisine",
      image: require("../assets/images/pizza.png"),
      description: "Hot and spicy pizzas",
      lng: -85.5324269,
      lat: 38.2145602,
      address: "Acasa",
      stars: 5,
      reviews: "224k",
      category: "Sushi",
      dishes: [
        {
          id: 1,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
        {
          id: 2,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
        {
          id: 3,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
      ],
    },
    {
      id: 3,
      name: "Smecheria lu Horia",
      image: require("../assets/images/pizza.png"),
      description: "Hot and spicy pizzas",
      lng: -85.5324269,
      lat: 38.2145602,
      address: "434 second street",
      stars: 4,
      reviews: "4.4k",
      category: "Burger",
      dishes: [
        {
          id: 1,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
        {
          id: 2,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
        {
          id: 3,
          name: "pizza",
          description: "cheezy garlic pizza",
          price: 10,
          image: require("../assets/images/pizzaDish.png"),
        },
      ],
    },
  ],
};
