import React from "react";
import { SafeAreaView, FlatList, Text, View, Button, Image } from "react-native";
import { useSelector, useDispatch } from "react-redux";
import { removeItemFromCart } from "../redux/cartSlice";
import { themeColors } from "../theme";

export default function CartScreen() {
  const cartItems = useSelector((state) => state.cart.items);
  const restaurantId = useSelector((state) => state.cart.restaurantId);
  const totalAmount = useSelector((state) => state.cart.totalAmount);
  const dispatch = useDispatch();

  const handleRemoveFromCart = (id) => {
    dispatch(removeItemFromCart(id));
  };

  return (
    <SafeAreaView className="flex-1 justify-center">
      <FlatList
        data={cartItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View className="ml-8">
            <Text
              className="font-bold text-xl mt-2"
              style={{ color: themeColors.text }}
            >
              {item.name}
            </Text>
            <Image className="w-2/5 h-24 rounded-2xl m-2" source={{ uri: item.imageUrl }} />
            <Text className="font-bold text-lg mt-4">
              Quantity: {item.quantity}
            </Text>
            <Text className="font-bold text-lg mb-2">
              Total: {(parseFloat(item.price) * parseFloat(item.quantity)).toFixed(2)} lei
            </Text>
            <Button title="Remove" onPress={() => handleRemoveFromCart(item.id)} />
          </View>
        )}
      />
      <View className="ml-8">
        <Text className="font-bold text-lg mt-4 mb-2">
          Total: {totalAmount.toFixed(2)} lei
        </Text>
        <Text
          className="font-bold text-xl mt-2"
          style={{ color: themeColors.text }}
        >
          {restaurantId}
        </Text>
      </View>
    </SafeAreaView>
  );
}
