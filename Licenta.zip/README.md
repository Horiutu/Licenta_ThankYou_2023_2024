# Licenta_ThankYou_2023_2024
Proiectul lui Chis Horia de licenta.
