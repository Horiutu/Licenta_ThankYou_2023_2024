export const themeColors={
    text: '#dc143c',
    text2: '#00FF00',
    bgColor: opacity=> `rgba(220, 20, 60, ${opacity})`
}
